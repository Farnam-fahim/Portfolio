// function show(){
// 	document.getElementsByClassName("text")[0].style.display = "visible";
// 	document.getElementsByClassName("text")[1].style.display = "visible";
// 	document.getElementsByClassName("text")[2].style.display = "visible";
// }	